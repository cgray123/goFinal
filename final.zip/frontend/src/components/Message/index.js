import Message from './Message.jsx'

export default Message;