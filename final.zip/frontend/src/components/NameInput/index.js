import NameInput from './NameInput.jsx'

export default NameInput;